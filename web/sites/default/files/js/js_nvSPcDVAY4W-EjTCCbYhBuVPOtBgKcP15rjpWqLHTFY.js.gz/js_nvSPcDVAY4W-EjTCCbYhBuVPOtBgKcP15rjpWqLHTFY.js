/**
 * @file
 * VillaAgency behaviors.
 */
(function (Drupal) {

  'use strict';

  Drupal.behaviors.villaagency = {
    attach (context, settings) {

      console.log('It works!');

    }
  };

} (Drupal));
;
